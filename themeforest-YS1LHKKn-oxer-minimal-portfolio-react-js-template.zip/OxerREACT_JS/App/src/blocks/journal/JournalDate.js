import React from 'react';

const JournalDate = () => {
    return (
        <p className="date"><span className="large">25</span> May, 2020</p>
    );
};

export default JournalDate;
