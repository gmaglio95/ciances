import React from 'react';

const Copyright = () => {
    return (
        <div className="copyright">
            <p>© 2020 Portfolio Template By <a href="https://www.adveits.com">Adveits</a></p>
        </div>
    );
};

export default Copyright;
