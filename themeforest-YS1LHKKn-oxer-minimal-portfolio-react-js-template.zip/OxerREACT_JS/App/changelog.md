# Oxer – Minimal Portfolio React JS Template
# https://store.adveits.com/item/oxer-minimal-portfolio-react-js-template/changelog/

## Changelog list:

### Version 1.1.0
Update: JS files
Update: Sass files

### Version 1.0.0
- Initial release